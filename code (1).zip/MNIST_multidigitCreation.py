from tensorflow.keras.datasets import mnist
from matplotlib import pyplot as plt
import numpy as np 
import random 
import cv2




def get_random_MNIST_digit(digit_label ):
    #get a random image with provided label  
    #digit_label=7
    train_index = np.where(y_train == digit_label ) #get all y trains with given label
    random_index = np.random.choice(train_index[0], size=1) #pick a random index 
    #digit = X_train[random_index][0,:,:] #get the 28x28 pixels of random index 
    digit = X_train[random_index][0] #get the 28x28 pixels of random index 
    
    return digit
 
                            
def display_img(img ):
    cv2.imshow( "",img )
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
def create_multidigit_img (randomlist):    
    #create 6 digit image by combining images in the randomlist
    final_image= np.zeros(shape=(28, 1))
    image_name =""
    for i in randomlist : 
        single_digit =get_random_MNIST_digit(i)
        final_image = np.hstack((final_image,single_digit))#combine arrays horizontally
        image_name = image_name+ str(i)
    return final_image , image_name

# load dataset
(X_train, y_train) , (X_test, y_test) = mnist.load_data()

randomlist = random.sample(range(0, 9), 6) 

final_image ,image_name =  create_multidigit_img (randomlist)  

print(image_name)   
display_img(final_image)   


