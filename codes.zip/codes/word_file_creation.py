# -*- coding: utf-8 -*-
"""
Created on Tue May 24 00:11:04 2022

@author: Hi
"""

# Import Module
import os

# Folder Path
path = "D:/HTRC/resized"

# Change the directory
os.chdir(path)

# Read text File


def read_text_file(file_path):
	with open(file_path, 'r') as f:
		print(f.read())

with open("words.txt",'w',encoding = 'utf-8') as f:
 
# iterate through all file
    for file in os.listdir(path):
        if len(file.split(".")) == 2:
            num = file.split(".")[0]
        elif len(file.split(".")) == 3:
            num = str(file.split(".")[0]+"."+file.split(".")[1])
        f.write(num +" "+num +"\n")
        
        print(file)
    	# Check whether file is in text format or not
    	
