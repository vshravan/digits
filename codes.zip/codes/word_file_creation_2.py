# -*- coding: utf-8 -*-
"""
Created on Fri Jun  3 13:38:57 2022

@author: Hi
"""

import pandas as pd

df =pd.read_excel("dataset_digits_5.xlsx")

with open("D:\HTR2\words_030622.txt",'w',encoding = 'utf-8') as f:
    for index, row in df.iterrows():
        f.write(str(row['image_name'])+".png"+" "+str(row['image_content'])+"\n")
 
# iterate through all file
    for i,file in enumerate(os.listdir(path)):
        print(file)
        if len(file.split(".")) == 2:
            if (file.split(".")[1]) == "png":
                num = file.split(".")[0].split("_")[0]
        elif len(file.split(".")) == 3:
             num = (str(file.split(".")[0]+"."+file.split(".")[1])).strip("_")[0]
        f.write(file+" "+num +"\n")