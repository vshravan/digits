# -*- coding: utf-8 -*-
"""
Created on Tue May 24 00:11:04 2022

@author: Hi
"""

# Import Module
import os

# Folder Path
path = "D:\HTR2\data_dir\img"

# Change the directory
os.chdir(path)

# Read text File


def read_text_file(file_path):
	with open(file_path, 'r') as f:
		print(f.read())

with open("D:\HTR2\words2_t.txt",'w',encoding = 'utf-8') as f:
 
# iterate through all file
    for i,file in enumerate(os.listdir(path)):
        print(file)
        if len(file.split(".")) == 2:
            if (file.split(".")[1]) == "png":
                num = file.split(".")[0].split("_")[0]
        elif len(file.split(".")) == 3:
             num = (str(file.split(".")[0]+"."+file.split(".")[1])).strip("_")[0]
        f.write(file+" "+num +"\n")
        
        print(file)
    	# Check whether file is in text format or not
    	
