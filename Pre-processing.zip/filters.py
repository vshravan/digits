# -*- coding: utf-8 -*-
"""
Created on Wed Apr 13 13:16:15 2022

@author: shari
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('opencv_logo.png')

def im_show(img):
    cv2.imshow('image',img)
    cv2.waitKey(0)
    
im_show(img)


def average_filter(img):
    kernel = np.ones((5,5),np.float32)/25
    #blur = cv2.blur(img,(5,5))
    dst = cv2.filter2D(img,-1,kernel) #to convolve a kernel with an image
    im_show(dst)
    
average_filter(img)

def gussian_filter(img):
    blur = cv2.GaussianBlur(img,(5,5),0)
    im_show(blur)

gussian_filter(img)

def median_filter():
    img = cv2.imread('salt_pepper.png')
    im_show(img)
    median = cv2.medianBlur(img,5)
    im_show(median)
median_filter()
    

    
