# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 13:45:13 2022

@author: shari
"""



import cv2
import numpy as np
from matplotlib import pyplot as plt 
from scipy.ndimage import interpolation as inter
from PIL import Image as im

img=cv2.imread('sample4.png')

# img_single_layer = img[:,:,0]

# new_img = []
# new_img[0]= img_single_layer

#img=cv2.imread('sample.png',cv2.IMREAD_GRAYSCALE)

def im_show(img):
    cv2.imshow('image',img)
    cv2.waitKey(0)
    
im_show(img)

#thinned = cv2.ximgproc.thinning(cv2.cvtColor(img, cv2.COLOR_RGB2GRAY))


#SCALING
def scaling(img):
    #downscaling
    scale_percent = 80 # percent of original size
    width = int(img.shape[1] * scale_percent / 100)
    height = int(img.shape[0] * scale_percent / 100)
    dim = (width, height)
    # resize image
    resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA) #cv2.INTER_AREA- shrink an image
    return resized
 
img_scaled=scaling(img)
im_show(img_scaled)
 

#Angle rotation
def correct_skew(image, delta=1, limit=5):
    #image=img_scaled
    def determine_score(arr, angle):
        #arr=thresh
        data = inter.rotate(arr, angle, reshape=False, order=0) # rotate array for given angle
        histogram = np.sum(data, axis=1) # calculates no. of pixels in each row 
        score = np.sum((histogram[1:] - histogram[:-1]) ** 2) # difference of each peaks calculated and find sum
        return histogram, score

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # gray scale
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1] #threshold returns tuple with 2 value 
        # 1st is th value was used for the thresholding and 2nd is the binary image that is extracting here

    scores = []
    angles = np.arange(-limit, limit + delta, delta) # a range of angles given to check -5 to 5
    for angle in angles:
        histogram, score = determine_score(thresh, angle) # for each angle to calculate histogram call determine_score
        scores.append(score)

    best_angle = angles[scores.index(max(scores))] # Maximum difference between peaks is skew angle.

    (h, w) = image.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, best_angle, 1.0)  #make transformation matrix center, angle of rotation and scaling
    rotated = cv2.warpAffine(image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE) # transformation matrix is rotated by affine transformation
        #which preserves lines and parallelism and rotated image will be returned

    return best_angle, rotated

angle, rotated = correct_skew(img_scaled)
im_show(rotated)


#Noise Removal
def spots_removal(binary_map):
    
    #binary_map=rotated
    binary_map = cv2.cvtColor(binary_map, cv2.COLOR_BGR2GRAY)
    
    # convert to binary by thresholding
    ret, binary_map = cv2.threshold(binary_map,127,255,0) #THRESH_BINARY = 0
    # do connected components processing
    nlabels, labels, stats, centroids = cv2.connectedComponentsWithStats(binary_map, None, None, None, 8, cv2.CV_32S)
    
    #get CC_STAT_AREA component as stats[label, COLUMN] 
    areas = stats[1:,cv2.CC_STAT_AREA]
    
    result = np.zeros((labels.shape), np.uint8)
    
    for i in range(0, nlabels - 1):
        if areas[i] >= 500:   #keep
            result[labels == i + 1] = 255
    return result

#img_gray = cv2.cvtColor(rotated, cv2.COLOR_BGR2GRAY)
result=spots_removal(rotated)
im_show(result)  
#im_show(img_gray)    

#increase contrast

#BINARIZATION
def Otsu_Binarization(img):
    #img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, imgf =   cv2.threshold(img, 0, 255,cv2.THRESH_BINARY,cv2.THRESH_OTSU) #imgf contains Binary image
    return imgf

image_bin=Otsu_Binarization(result)
im_show(image_bin)  






def erosion_dilation(image_bin):
    kernel = np.ones((3,3), np.uint8)
    #img_dilation = cv2.dilate(result, kernel, iterations=1)
    img_erosion = cv2.erode(image_bin, kernel, iterations=1)
    #im_show(img_dilation
    im_show(img_erosion)
    
erosion_dilation(image_bin)
