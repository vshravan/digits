# -*- coding: utf-8 -*-
"""
Created on Wed Apr 13 13:16:15 2022

@author: shari
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('opencv_logo.png')

def im_show(img):
    cv2.imshow('image',img)
    cv2.waitKey(0)
    
im_show(img)

def average_filter(img):
    kernel = np.ones((5,5),np.float32)/25
    #blur = cv2.blur(img,(5,5))
    dst = cv2.filter2D(img,-1,kernel) #to convolve a kernel with an image
    im_show(dst)

    
average_filter(img)

def gussian_filter(img):
    blur = cv2.GaussianBlur(img,(5,5),0)
    im_show(blur)

gussian_filter(img)


def add_noise(img):
	# Getting the dimensions of the image
	row , col = img.shape
    # Randomly pick some pixels in th image for coloring them white. Pick a random number between 300 and 10000
	number_of_pixels = random.randint(300, 10000)
	for i in range(number_of_pixels):
	    # Pick a random y coordinate
		y_coord=random.randint(0, row - 1)
		
		# Pick a random x coordinate
		x_coord=random.randint(0, col - 1)
		
		# Color that pixel to white
		img[y_coord][x_coord] = 255
		
	# Randomly pick some pixels in # the image for coloring them black # Pick a random number between 300 and 10000
	number_of_pixels = random.randint(300 , 10000)
	for i in range(number_of_pixels):
	
		# Pick a random y coordinate
		y_coord=random.randint(0, row - 1)
		
		# Pick a random x coordinate
		x_coord=random.randint(0, col - 1)
		
		# Color that pixel to black
		img[y_coord][x_coord] = 0
	return img

img = cv2.imread('image4.png',cv2.IMREAD_GRAYSCALE)

cv2.imwrite('salt_pepper_test.jpg',add_noise(img))

img = cv2.imread('salt_pepper_test.jpg')
im_show(img)

def median_filter(img):
    median = cv2.medianBlur(img,5)
    im_show(median)
    
median_filter(img)

blur = cv2.bilateralFilter(img,9,75,75)

im_show(blur)    

    
