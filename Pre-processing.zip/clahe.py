# -*- coding: utf-8 -*-
"""
Created on Wed Apr 13 00:48:44 2022

@author: shari
"""

import cv2
import numpy as np
 
# Reading the image from the present directory
image = cv2.imread("clahe.png")

def im_show(img):
    cv2.imshow('image',img)
    cv2.waitKey(0)
    
im_show(image)

def clahe(image):
    # Resizing the image for compatibility
    image = cv2.resize(image, (500, 600))
     
    # The initial processing of the image
    # image = cv2.medianBlur(image, 3)
    image_bw = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
     
    # The declaration of CLAHE
    # clipLimit -> Threshold for contrast limiting
    clahe = cv2.createCLAHE(clipLimit = 5)
    final_img = clahe.apply(image_bw) +30
    
    # clahe = cv2.createCLAHE(clipLimit = 5)
    # final_img = clahe.apply(image_bw) + 30
     
    # Ordinary thresholding the same image
    thr, ordinary_img = cv2.threshold(image_bw, 155, 255, cv2.THRESH_BINARY)
    return final_img

contrast_img=clahe(image)
im_show(contrast_img)

