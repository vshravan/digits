# -*- coding: utf-8 -*-
"""
Created on Mon Oct 10 15:08:05 2022

@author: Hi
"""

# import libraries
import numpy as np

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

import torch
import torch.nn as nn
import torch.nn.functional as F

import cv2

import matplotlib.pyplot as plt
from IPython import display
display.set_matplotlib_formats('svg')
import copy

import glob
import os
import requests
import sys
import random
import itertools
from typing import Tuple
from PIL import Image, ImageDraw, ImageFont

def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn 
warnings.filterwarnings("ignore", category=UserWarning)

from scipy.spatial.distance import cosine, euclidean, cdist
import tensorflow 

import PIL
import numpy as np
import tensorflow as tf
import pandas as pd
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.models import Model
from tensorflow.keras import layers  
# %load_ext nb_black
from tqdm.notebook import tqdm 
  
from skimage.filters import try_all_threshold, threshold_otsu
from tensorflow.keras.applications import resnet, EfficientNetB0
from sklearn.metrics import roc_curve

tf.random.set_seed(2018) 
np.random.RandomState(2018)
random.seed(2018) 


def PSNR(y_true, y_pred): 
    # should be between 30 and 50. Higher the better
    return tf.image.psnr(y_true, y_pred, max_val=1.0)

def SSIM(y_true, y_pred): 
  # betweeen 0 and 1. Higher the better
    return tf.image.ssim(y_true, y_pred, max_val=1.0)

model_imported=tf.keras.models.load_model('line_removal_model_parameter_turning2',custom_objects = {"PSNR": PSNR, "RMSE": tf.keras.metrics.RootMeanSquaredError(name="rmse"),"SSIM":SSIM}, compile=False)

TEST_PATH = "D:/HTR1/Autoencoders/test1" 
test_images = []
for path, subdirs, files in os.walk(TEST_PATH):
    for name in files:
        image_path = os.path.join(path, name)
        if "png" or "PNG" in image_path:
          test_images.append(image_path)
          
def threshold_image(img_arr):
  thresh = threshold_otsu(img_arr)
  return np.where(img_arr > thresh, 255, 0)
          
def load_img_np(img_path):
  img_np = load_img(img_path)
  img_np = np.squeeze(img_to_array(img_np))  
  img_np = threshold_image(img_np)  
  return img_np

from scipy.ndimage.measurements import center_of_mass 
import math

height =64
width=256
          
def image_padding(image):
    (h, w) = image.shape[:2]
    #padding on image
    colsPadding = (int(math.ceil((width-w)/2.0)),int(math.floor((width-w)/2.0)))
    rowsPadding = (int(math.ceil((height-h)/2.0)),int(math.floor((height-h)/2.0)))
    #gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    #gray_image = 255-gray_image 
    #plt.imshow(gray_image)

    #updated portion
    #gray_image = 255-gray_image 

    #dataNorm = gray_image / np.max(gray_image)

    
    image_padded = np.lib.pad(image,(rowsPadding,colsPadding),'constant',constant_values=(255,255))
    #plt.imshow(image_padded)
    
    
    cy,cx = center_of_mass(image_padded)

    rows,cols = image_padded.shape
    shiftx = np.round(cols/2.0-cx).astype(int)
    shifty = np.round(rows/2.0-cy).astype(int)
    
    
#def getBestShift(img):
    cy,cx = center_of_mass(image_padded)

    rows,cols = image_padded.shape
    shiftx = np.round(cols/2.0-cx).astype(int)
    shifty = np.round(rows/2.0-cy).astype(int)

    #return shiftx,shifty
    
    rows,cols = image_padded.shape
    M = np.float32([[1,0,shiftx],[0,1,shifty]])
    shifted = cv2.warpAffine(image_padded,M,(cols,rows))
    #plt.imshow(shifted)
    #print(shifted.shape)
    
    return shifted


def resize_without_distortion(img):
  def image_resize(image, width, height , inter = cv2.INTER_AREA):
    
    dim=None
    (h, w) = image.shape[:2]
    
    # 1. return original image
    if width is w and height is h:
      print("Same image")
      return image
    
    
    #2.image is small
    elif w<width or  h<height:
        
      wt_ratio=width/float(w)
      ht_ratio=height/float(h)
        
      #too small
      if wt_ratio >=2 and ht_ratio>=2:
        if wt_ratio<ht_ratio:
          #print("Too small 1 case")
          dim=(int(w * wt_ratio), int(h * wt_ratio))
          resized = cv2.resize(image, dim)
                
          #padding on height 
          final_image=image_padding(resized)
          #plt.imshow(final_image)
          return final_image
         
        else:
          #print("Too small 2 case")
          dim=dim = (int(w * ht_ratio), int(h * ht_ratio))
          resized = cv2.resize(image, dim)
                
          #padding on width
          final_image=image_padding(resized)
          #plt.imshow(final_image)
          return final_image
                
            
            #image Padding
      else:
        #print("Small image Padding ")
        #print("Small image Padding ")
        #
        if w<width and h<height:
            #print("1")
            final_image=image_padding(image)
            #plt.imshow(final_image)
            return final_image
        elif w<width and h>height:
            #print("2")
            dim=(w, height)
            resized = cv2.resize(image, dim)
            print(resized.shape)
            final_image=image_padding(resized)
            return final_image
        else:
            #print("3")
            dim=(width, h)
            resized = cv2.resize(image, dim)
            final_image=image_padding(resized)
            return final_image
        #final_image=image_padding(image)
        #plt.imshow(final_image)
        #return final_image
    
    #Large size
    else:
        wt_ratio=w/float(width)
        ht_ratio=h/float(height)
        if wt_ratio>ht_ratio:
            #print("Large image 1 case")
            dim=(int(w /float(wt_ratio)), int(h / float(wt_ratio)))
            resized = cv2.resize(image, dim)
            
            #padding on height 
            final_image=image_padding(resized)
            return final_image
            #plt.imshow(final_image)
        else:
            #print("Large image 2 case")
            dim=(int(w /float(ht_ratio)), int(h / float(ht_ratio)))
            resized = cv2.resize(image, dim)
            
            #padding on height 
            final_image=image_padding(resized)
            return final_image
            #plt.imshow(final_image)

  result_image= image_resize(img, width, height , inter = cv2.INTER_AREA)
  return result_image

clean_holder = []
for img in test_images: 
  img_np =  load_img_np(img)


  # img_np = threshold_image(img_np)   
  #image = Image.fromarray(np.uint8(img_np)).convert('RGB') 
  image = Image.fromarray(np.uint8(img_np))

    
  open_cv_image = np.array(image)
  #plt.imshow(open_cv_image)
  #print(open_cv_image.shape)

  gray_image = cv2.cvtColor(open_cv_image, cv2.COLOR_BGR2GRAY)
  gray_image = 255-gray_image 
    
  clean_image = resize_without_distortion(gray_image)
  #print(clean_image.shape)

  clean_image = 255-clean_image  
  color_coverted = cv2.cvtColor(clean_image, cv2.COLOR_GRAY2RGB)
  pil_image=Image.fromarray(color_coverted)
  #clean_image = image.resize((img_target_size))
  clean_holder.append( threshold_image(np.array(pil_image)) * (1./255))  
  
  result=np.array(clean_holder)
  
predicted_test = model_imported.predict(result)

fig,ax = plt.subplots(2,8,figsize=(15,3))

for i in range(8):
    
  ax[0,i].imshow(result[i])
  ax[0,i].set_xticks([]), ax[0,i].set_yticks([])
  fig.suptitle('Noisy Images', fontweight ="bold")
  
  ax[1,i].imshow(predicted_test[i]  )
  ax[1,i].set_xticks([]), ax[1,i].set_yticks([])
  #fig.suptitle('Cleaned Images', fontweight ="bold")

plt.show()

