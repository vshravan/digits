# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 21:30:33 2022

@author: shari
"""

from tensorflow.keras.datasets import mnist
from matplotlib import pyplot as plt
import numpy as np 
import random 
import cv2




def get_random_MNIST_digit(digit_label ):
    #get a random image with provided label    
    train_index = np.where(y_train == digit_label ) #get all y trains with given label
    random_index = np.random.choice(train_index[0], size=1) #pick a random index 
    digit = X_train[random_index][0,:,:] #get the 28x28 pixels of random index 
    return digit
 
                            
def display_img(img ):
    cv2.imshow( "",img )
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
def create_multidigit_img (randomlist) :    
    #create 6 digit image by combining images in the randomlist
    final_image= np.zeros(shape=(28, 1))
    image_name =""
    for i in randomlist : 
        single_digit =get_random_MNIST_digit(i)
        single_digit_padded = add_padding (single_digit)        
        final_image= np.hstack((final_image,single_digit_padded))#combine arrays horizontally
        image_name = image_name+ str(i) 
    return final_image , image_name

def add_padding (img): 
        number_of_columns = random.sample(range(0, 15),1)[0]
        padding_image = np.zeros(shape=(28, number_of_columns))
        padded_image = np.hstack((img,padding_image))
        return padded_image
    
# load dataset
(X_train, y_train) , (X_test, y_test) = mnist.load_data()
number_of_digits = 10
randomlist =[]
for i in range (0,number_of_digits) :
    random_number = random.sample(range(0, 9),1)[0] #random.sample gives list format- take 0 index
    randomlist.append(random_number)
    
final_image ,image_name =  create_multidigit_img (randomlist)  

print(image_name)   
display_img(final_image)   

 
        