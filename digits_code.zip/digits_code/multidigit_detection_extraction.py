# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 22:43:16 2022

@author: shari
"""

import pandas as pd
import cv2
import numpy as np
import imutils

#364.png
#test2.jpg
#3875.jpeg
image=cv2.imread("sample.png")#Read image


def display_img(img):
    cv2.imshow( "image" ,img )
    cv2.waitKey(0)
    cv2.destroyAllWindows()


# cv2.imshow( "",image )
# cv2.waitKey(0)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) #convert to gray
bin_img = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)[1] #convert to binary

#invert image
inverted_img=cv2.bitwise_not(bin_img)

#dilate image
kernel=np.ones((1,1),np.uint8)
img_dilation=cv2.dilate(inverted_img,kernel,iterations=1)

#detect image
edged=cv2.Canny(img_dilation,30,200)

#dilate image
kernel=np.ones((3,3),np.uint8)
img_dilation=cv2.dilate(edged,kernel,iterations=1)

# cv2.imshow( "",img_dilation )
# cv2.waitKey(0)

#Segmentaion

cnts = cv2.findContours(img_dilation, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

cnts = imutils.grab_contours(cnts)

cnts=sorted(cnts,key=cv2.boundingRect) 

image_list=[]
extracted_images=[]
for c in cnts:
    x,y,w,h=cv2.boundingRect(c)
    digit_image = gray[y:y+h,x:x+w]
    extracted_images.append(digit_image)
    ROI=255-image[y:y+h,x:x+w]
    image_list.append(ROI)
    cv2.rectangle(gray,(x,y),(x+w,y+h),(36,255,12),2)
    display_img(digit_image)
    # if w >= 15 and (h >= 30 and h <= 40):
    #     ROI=255-image[y:y+h,x:x+w]
    #     image_list.append(ROI)
    #cv2.rectangle(gray,(10,20),(40,60),(36,255,12),2)
    
display_img(gray)



