# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 10:44:09 2022

@author: shari
"""


# import libraries
import numpy as np

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

import torch
import torch.nn as nn
import torch.nn.functional as F

import cv2

import matplotlib.pyplot as plt
from IPython import display
display.set_matplotlib_formats('svg')
import copy

import glob

#Preprocessing on input images-resizing,normalizing, convert to tensor etc
filelist = glob.glob('mutidigit_dataset/*.png')
img_count=len(filelist)
def image_preprocessing(filelist):
    i=0
    imagesOcc   = torch.zeros(img_count,1,56,224)
    imagesNoOcc = torch.zeros(img_count,1,56,224)
    for fname in filelist:
        #print(fname)
        img=cv2.imread(fname)
        gray_image = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

        img_resize = cv2.resize(255-gray_image, (224,56)) 
        
        dataNorm = img_resize / np.max(img_resize)


        # convert to tensor
        dataT= torch.tensor( dataNorm ).float()
        
        img=dataT
        
        imagesNoOcc[i,:,:,:]=torch.Tensor(dataT).view(1,56,224)
        
        occluded = copy.deepcopy( img )
        i1 = np.random.choice(np.arange(25,30))
        i2 = np.random.choice(np.arange(2,4))
        occluded[i1:i1+i2,] = 1
        
    
        imagesOcc[i,:,:,:] = torch.Tensor(occluded).view(1,56,224)
        i=i+1
    return imagesNoOcc,imagesOcc

#create a line on input images(making occlusion)
imagesNoOcc,imagesOcc=image_preprocessing(filelist)

#Image Visulaization
fig,ax = plt.subplots(2,10,figsize=(15,3))

for i in range(10):
  whichpic = np.random.randint(img_count)
  ax[0,i].imshow(np.squeeze( imagesNoOcc[whichpic,:,:] ),vmin=-1,vmax=1,cmap='jet')
  ax[0,i].set_xticks([]), ax[0,i].set_yticks([])
  
  ax[1,i].imshow(np.squeeze( imagesOcc[whichpic,:,:] ),vmin=-1,vmax=1,cmap='jet')
  ax[1,i].set_xticks([]), ax[1,i].set_yticks([])

plt.show()


#Create a class for the model
def makeTheNet():

  class gausnet(nn.Module):
    def __init__(self):
      super().__init__()
      
      # encoding layer
      self.enc = nn.Sequential(
          nn.Conv2d(1, 16, 3, stride=2, padding=1),
          nn.ReLU(),
          nn.Conv2d(16, 32, 3, stride=2, padding=1),
          nn.ReLU(),
          nn.Conv2d(32, 64, 7),

   
          )
      
      # decoding layer
      self.dec = nn.Sequential(
          nn.ConvTranspose2d(64, 32, 7),
          nn.ReLU(),
          nn.ConvTranspose2d(32, 16, 3, stride=2, padding=1, output_padding=1),
          nn.ReLU(),
          nn.ConvTranspose2d(16, 1, 3, stride=2, padding=1, output_padding=1),
          nn.Sigmoid()
          )
      
    def forward(self,x):
      return self.dec( self.enc(x) )
  
  # create the model instance
  net = gausnet()
  
  # loss function
  lossfun = nn.MSELoss()

  # optimizer
  optimizer = torch.optim.Adam(net.parameters(),lr=.001)

  return net,lossfun,optimizer

# Test the model with one batch
net,lossfun,optimizer = makeTheNet()

yHat = net(imagesOcc[:5,:,:,:])

# check size of output
print(' ')
print(yHat.shape)
print(imagesOcc.shape)


# let's see how they look
fig,ax = plt.subplots(1,2,figsize=(8,3))
ax[0].imshow(torch.squeeze(imagesOcc[0,0,:,:]).detach(),cmap='jet')
ax[0].set_title('Model input')
ax[1].imshow(torch.squeeze(yHat[0,0,:,:]).detach(),cmap='jet')
ax[1].set_title('Model output')

plt.show()


# a function that trains the model

def function2trainTheModel():

  # number of epochs
  numepochs = 1000
  
  # create a new model
  net,lossfun,optimizer = makeTheNet()

  # initialize losses
  losses = torch.zeros(numepochs)

  # loop over epochs
  for epochi in range(numepochs):
      
    print("Epoch no: ",epochi)
      
    # pick a set of images at random
    pics2use = np.random.choice(img_count,size=32,replace=False)

    # get the input (has occlusions) and the target (no occlusions)
    X = imagesOcc[pics2use,:,:,:]
    Y = imagesNoOcc[pics2use,:,:,:]

    # forward pass and loss
    yHat = net(X)
    loss = lossfun(yHat,Y)
    losses[epochi] = loss.item()

    # backprop
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

  # end epochs

  # function output
  return losses,net

# test the model on a bit of data
losses,net = function2trainTheModel()

#Save the trained model
file='model.pth'
torch.save(net.state_dict(), file)



plt.plot(losses,'s-',label='Train')
plt.xlabel('Epochs')
plt.ylabel('Loss (MSE)')
plt.title('Model loss')

plt.show()

# #visualize some images for output

pics2use = np.random.choice(img_count,size=32,replace=False)
X = imagesOcc[pics2use,:,:,:]
yHat = net(X)

fig,axs = plt.subplots(2,10,figsize=(15,3))

for i in range(10):
  
  G = torch.squeeze( X[i,0,:,:] ).detach()
  O = torch.squeeze( yHat[i,0,:,:] ).detach()
  
  axs[0,i].imshow(G,vmin=-1,vmax=1,cmap='jet')
  axs[0,i].axis('off')
  axs[0,i].set_title('Model input',fontsize=10)

  axs[1,i].imshow(O,vmin=-1,vmax=1,cmap='jet')
  axs[1,i].axis('off')
  axs[1,i].set_title('Model output',fontsize=10)

plt.show()

