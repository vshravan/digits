# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 10:44:10 2022

@author: shari
"""



# import libraries
import numpy as np

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

import torch
import torch.nn as nn
import torch.nn.functional as F

import cv2

import matplotlib.pyplot as plt
from IPython import display
display.set_matplotlib_formats('svg')
import copy


#Preprocessing on input image
def image_preprocessing(img):
    
    imagesOcc   = torch.zeros(1,1, 56,224)
    imagesNoOcc = torch.zeros(1,1,56,224)
    
    
    gray_image = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    #display_img(gray_image )
    img_resize = cv2.resize(255-gray_image, (224,56)) 
    
    dataNorm = img_resize / np.max(img_resize)

    # convert to tensor
    dataT= torch.tensor( dataNorm).float()
    
    img=dataT
    
    imagesNoOcc=torch.Tensor(dataT).view(1,56,224)
    
    occluded = copy.deepcopy( img )
    i1 = np.random.choice(np.arange(25,30))
    i2 = np.random.choice(np.arange(2,4))
    occluded[i1:i1+i2,] = 1
    
 
    imagesOcc= torch.Tensor(occluded).view(1,56,224)

    return imagesNoOcc,imagesOcc

#Read image
img=cv2.imread('sample.png')

#Make a line or occlusion on the input image
imagesNoOcc,imagesOcc=image_preprocessing(img)

#Visualization of image
#Gray Scale image
I1 = torch.squeeze( imagesNoOcc).detach()
I2 = torch.squeeze( imagesOcc).detach()

tensor1  =I1.cpu().numpy()
RGB_image1 = cv2.cvtColor(tensor1,cv2.COLOR_GRAY2RGB)
tensor2  =I2.cpu().numpy()
RGB_image2 = cv2.cvtColor(tensor2,cv2.COLOR_GRAY2RGB)


fig,ax = plt.subplots(2,1,figsize=(15,3))
ax[0].imshow(tensor1)
ax[0].set_xticks([]), ax[0].set_yticks([])


ax[1].imshow(tensor2)
ax[1].set_xticks([]), ax[1].set_yticks([])
plt.show()

#Tensor Image Visualization 
fig,ax = plt.subplots(2,1,figsize=(15,3))
ax[0].imshow(np.squeeze( imagesNoOcc ),vmin=-1,vmax=1,cmap='jet')
ax[0].set_xticks([]), ax[0].set_yticks([])
  
ax[1].imshow(np.squeeze( imagesOcc ),vmin=-1,vmax=1,cmap='jet')
ax[1].set_xticks([]), ax[1].set_yticks([])
plt.show()




# create a class for the model
def makeTheNet():

  class gausnet(nn.Module):
    def __init__(self):
      super().__init__()
      
      # encoding layer
      self.enc = nn.Sequential(
          nn.Conv2d(1, 16, 3, stride=2, padding=1),
          nn.ReLU(),
          nn.Conv2d(16, 32, 3, stride=2, padding=1),
          nn.ReLU(),
          nn.Conv2d(32, 64, 7),

   
          )
      
      # decoding layer
      self.dec = nn.Sequential(
          nn.ConvTranspose2d(64, 32, 7),
          nn.ReLU(),
          nn.ConvTranspose2d(32, 16, 3, stride=2, padding=1, output_padding=1),
          nn.ReLU(),
          nn.ConvTranspose2d(16, 1, 3, stride=2, padding=1, output_padding=1),
          nn.Sigmoid()
          )
      
    def forward(self,x):
      return self.dec( self.enc(x) )
  
  # create the model instance
  net = gausnet()
  
  # loss function
  lossfun = nn.MSELoss()

  # optimizer
  optimizer = torch.optim.Adam(net.parameters(),lr=.001)

  return net,lossfun,optimizer

# test the model with one batch
net,lossfun,optimizer = makeTheNet()


#Lpad the saved model
net.load_state_dict(torch.load('model.pth'))


#Inference model
X = imagesOcc
yHat = net(X)

#Image Visulaization 

#RGB image 
I3 = torch.squeeze(X).detach()
I4 = torch.squeeze(yHat).detach()

tensor3  =I3.cpu().numpy()
RGB_image3 = cv2.cvtColor(tensor3,cv2.COLOR_GRAY2RGB)
tensor4  =I4.cpu().numpy()
RGB_image4 = cv2.cvtColor(tensor4,cv2.COLOR_GRAY2RGB)

fig,ax = plt.subplots(2,1,figsize=(15,3))
ax[0].imshow(RGB_image3)
ax[0].set_xticks([]), ax[0].set_yticks([])


ax[1].imshow(RGB_image4)
ax[1].set_xticks([]), ax[1].set_yticks([])
plt.show()


#Tensor Images
X = imagesOcc
yHat = net(X)
 
fig,axs = plt.subplots(2,1,figsize=(15,3))


G = torch.squeeze( X).detach()
O = torch.squeeze( yHat ).detach()

axs[0].imshow(G,vmin=-1,vmax=1,cmap='jet')
axs[0].axis('off')
axs[0].set_title('Model input',fontsize=5)

axs[1].imshow(O,vmin=-1,vmax=1,cmap='jet')
axs[1].axis('off')
axs[1].set_title('Model output',fontsize=5)

plt.show()



